import { Component } from '@angular/core';

@Component({
  selector: 'app-joinus',
  templateUrl: './joinuspage.component.html',
  styleUrls: ['./joinuspage.component.css']
})
export class JoinusComponent {
  Firstname: String = '';
  Lastname: String = '';
  Email: String = '';
  School: String = '';
  Join = 'Fill up the Form to join';

  clearForm() {
    this.Firstname = '';
    this.Lastname = '';
    this.Email = '';
    this.School = '';
}
}