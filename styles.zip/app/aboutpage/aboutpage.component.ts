import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './aboutpage.component.html',
  styleUrls: ['./aboutpage.component.css']
})
export class AboutpageComponent {
  about = 'About'
  description = 'Welcome to CLICK COUNTERHUB your go-to destination for tracking and analyzing clicks with ease! Our intuitive click counter tool empowers you to effortlessly monitor and tally user interactions on your website, social media posts, or any digital content. Whether you are a content creator, marketer, or simply curious about engagement, our user-friendly interface allows you to click away stress-free.';
  over = 'Empower your digital journey with CLICK COUNTERHUB – where every click tells a story! Join us in unraveling the fascinating world of online engagement. Do you like it or dislike it?';

  feedbackText: string = ''; // Variable to store feedback text

  like() {
    this.feedbackText = 'Thank you for liking!';
  }

  dislike() {
    this.feedbackText = 'We are sorry, we will try to improve!';
  }
}