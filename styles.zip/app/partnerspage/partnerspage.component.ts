import { Component } from '@angular/core';

@Component({
  selector: 'app-partners',
  templateUrl: './partners.component.html',
  styleUrls: ['./partners.component.css']
})
export class PartnersComponent {
  partners = 'Partners who help me to do this social experiment.';
  showText: boolean = false;

toggleText() {
  this.showText = !this.showText;
}

staff = [ 
  { Name: 'Chelsea',  age: '25', role: 'Graphic Artist' },   
  { Name: 'Gino',  age: '27', role: 'Photographer' }, 
  { Name: 'Alan',  age: '25', role: 'Web Developer' }, 
  { Name: 'Colee', age: '20', role: 'Web Design' }, 
  ];

  roles = 'Click to see their ages and roles.';
}