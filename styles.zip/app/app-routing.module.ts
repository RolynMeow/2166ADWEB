import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutpageComponent } from './aboutpage/aboutpage.component';
import { AppComponent } from './app.component';
import { PartnersComponent } from './partnerspage/partnerspage.component';
import { JoinusComponent } from './joinuspage/joinuspage.component';
import { MainComponent } from './mainpage/mainpage.component';

const routes: Routes = [
  
  {
    path:'app',
    component: AppComponent
  },
    {path:'about',
    component: AboutpageComponent
  },
    {path:'partners',
  component: PartnersComponent
},{
  path:'joinus',
component: JoinusComponent
},
{
  path:'main',
component: MainComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }