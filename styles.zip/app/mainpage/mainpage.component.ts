import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainComponent {
  title = 'prelimexam';
  
  clientName = 'CLICK COUNTERHUB';
  update = 'Press any Button to start';
 
  clickCountLike=0
  clickCountDislike=0
  clickMeLike(){
    this.clickCountLike++;
  }
  clickMeDislike(){
    this.clickCountDislike++;
  }
  
}